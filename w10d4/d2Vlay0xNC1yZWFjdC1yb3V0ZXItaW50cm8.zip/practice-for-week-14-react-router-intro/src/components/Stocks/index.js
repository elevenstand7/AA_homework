function Stocks() {
  return (
    <div className='comp orange'>
      <h1>Stocks Component</h1>
    </div>
  );
}

export default Stocks;
