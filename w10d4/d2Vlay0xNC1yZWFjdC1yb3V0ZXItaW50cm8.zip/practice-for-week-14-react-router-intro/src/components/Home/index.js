function Home() {
  return (
    <div className="comp orange">
      <h1>Home Component</h1>
    </div>
  );
}

export default Home;
