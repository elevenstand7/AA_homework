export const moves = [
  { id: 1, type: 'normal', level: 1, move: 'growl' },
  { id: 2, type: 'normal', level: 1, move: 'tackle' },
  { id: 3, type: 'grass', level: 3, move: 'vine whip' },
  { id: 4, type: 'normal', level: 6, move: 'growth' },
  { id: 5, type: 'grass', level: 9, move: 'leech seed' },
  { id: 6, type: 'grass', level: 12, move: 'razor leaf' },
  { id: 7, type: 'poison', level: 15, move: 'poison powder' },
  { id: 8, type: 'grass', level: 15, move: 'sleep powder' },
  { id: 9, type: 'grass', level: 18, move: 'seed bomb' },
  { id: 10, type: 'normal', level: 21, move: 'take down' },
  { id: 11, type: 'normal', level: 24, move: 'sweet scent' },
  { id: 12, type: 'grass', level: 27, move: 'synthesis' }
];
