import PupImage from './PupImage';

export default PupImage;
