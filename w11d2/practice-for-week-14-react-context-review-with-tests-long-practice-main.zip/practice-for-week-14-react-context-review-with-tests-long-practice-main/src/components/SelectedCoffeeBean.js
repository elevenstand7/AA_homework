const SelectedCoffeeBean = () => {
  return (
    <div className="selected-coffee">
      <h2>Current Selection: </h2>
    </div>
  );
}

export default SelectedCoffeeBean;